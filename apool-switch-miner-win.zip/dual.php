<?php
$FileWay = 'log.txt';

$qubic_act_miner = true;
$idle_act_miner = false;

$qubic_act = true;
$idle_act = false;

$cmd = 'qubic.bat';
execInBackground($cmd);
echo 'start qubic' . PHP_EOL;

sleep(15);

while (true) {
		
	$handle = fopen($FileWay, 'r');
	if ($handle) {
		while ($string = fgets($handle)) {
			
			if (strpos($string, 'qubic mining work now!') !== false) {
				$qubic_act = true;
				$idle_act = false;				
			} elseif(strpos($string, 'qubic mining idle now!') !== false) {
				$qubic_act = false;
				$idle_act = true;
			}	
		}	
		if (!feof($handle)) {echo "Error: unexpected fgets() fail\n";}
			
		
		fclose($handle);
	}
	
	if ($qubic_act && !$qubic_act_miner) {

		execInBackground('stop_idle_miner.bat');
		$qubic_act_miner = true;
		$idle_act_miner = false;
		echo 'start qubic' . PHP_EOL;;
		
	} elseif ($idle_act && !$idle_act_miner) {

		execInBackground('idle_miner.bat');
		$qubic_act_miner = false;
		$idle_act_miner = true;
		echo 'start idle miner' . PHP_EOL;
	}	
	
	echo date('d.m.Y G:i:s', time()) . PHP_EOL;
	
	sleep(5);
}

function execInBackground($cmd)
{
	if (substr(php_uname(), 0, 7) == "Windows") {
		
		pclose(popen("start ". $cmd, "w"));
		
	} else {
		
		exec($cmd . " > /dev/null &");
	}
}